<?php

namespace App\Models;

use CodeIgniter\model;

class DeviceModel extends Model
{
    protected $table = 'device';
    protected $useTimestamps = false;
}
