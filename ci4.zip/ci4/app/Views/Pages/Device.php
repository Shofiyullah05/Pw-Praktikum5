<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<div class="container">
    <div class="row">
        <div class="col">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nama Device</th>
                        <th scope="col">Brand Device</th>
                        <th scope="col">Jumlah Device</th>
                        <th scope="col">Status Device Device</th>
                    </tr>
                </thead>
                <tbody class="table-success">
                    <?php
                    foreach ($device as $listItem) {
                    ?>
                        <tr>
                            <?php
                            foreach ($listItem as $item) {
                            ?>
                                <td><?= $item ?></td>
                            <?php
                            }
                            ?>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>

        </div>
    </div>
</div>

<?= $this->endSection(); ?>