<?php

namespace App\Controllers;

use App\Models\DeviceModel;

class Pages extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Home | Web'
        ];

        return view('Pages/Home', $data);
    }
    public function about()
    {
        $DeviceModel = new DeviceModel();
        $device = $DeviceModel->findAll();
        $data = [
            'title' => 'Device',
            'device' => $device
        ];

        return view('Pages/Device', $data);
    }
}
